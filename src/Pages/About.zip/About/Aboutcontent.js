const cardData = [
  {
    id: 1,
    image: "images/explore.png",
    title: "Explore",
    body: " Find and research top hospitals & destinations ",
  },
  {
    id: 2,
    image: "images/heart.png",
    title: "Match",
    body: "Based on your criteria, we recommend the best hospitals or providers",
  },
  {
    id: 3,
    image: "images/arrange.png",
    title: "Arrange",
    body: "The provider will contact you directly to coordinate your treatment",
  },
  {
    id: 3,
    image: "images/care.png",
    title: "Treat",
    body: "Finalize your treatment with the hospital/provider of your choice",
  },
];

export default cardData;
