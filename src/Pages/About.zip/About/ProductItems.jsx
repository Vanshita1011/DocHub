import React from "react";
import { Card, Col } from "react-bootstrap";

function ProductItems({ pitems }) {
  return (
    <Col lg={4} md={12} sm={12} className="my-4">
      <Card>
        <Card.Img variant="top" src={pitems.image} alt="icon" />
        <Card.Body>
          <Card.Text>{pitems.body}</Card.Text>
        </Card.Body>
      </Card>
    </Col>
  );
}

export default ProductItems;
