import React from "react";
import { Card, CardTitle, Col } from "react-bootstrap";
import "./Aboutcard.css";

export default function AboutCard({ cardItems }) {
  return (
    <Col lg={3} md={6} sm={12} className="p-4">
      <Card className="hover-shadow-box-animation">
        <Card.Img variant="top" src={cardItems.image} alt="icon" />
        <Card.Body>
          <CardTitle className="fw-bold">{cardItems.title}</CardTitle>
          <Card.Text>{cardItems.body}</Card.Text>
        </Card.Body>
      </Card>
    </Col>
  );
}
