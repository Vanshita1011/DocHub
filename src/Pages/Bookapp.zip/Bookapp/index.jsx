import React, { useState } from "react";
import "./Bookapp.css";
import doctorsData from "./Doctorcontent";
import DoctorCard from "./DoctorCard";
import Header from "../../common/Header";
import Footer from "../../common/footer";
import { Button, Col, Container, Modal, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot, faSearch } from "@fortawesome/free-solid-svg-icons";
import ScrollToTop from "react-scroll-to-top";

export default function Bookapp() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [errors, setErrors] = useState({}); // Validation errors
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    appoinmentDate: "",
    hospital: "",
    doctor: "",
  });

  const [selectedHospital, setSelectedHospital] = useState(""); // State for selected hospital

  // Filter doctors based on search query and hospital
  const filteredDoctors = doctorsData.filter((doctor) => {
    const matchesName = doctor.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesHospital =
      selectedHospital === "" || doctor.hospital === selectedHospital;
    return matchesName && matchesHospital;
  });

  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Validate form
  const validateForm = () => {
    let newErrors = {};
    const nameRegex = /^[A-Za-z\s]+$/;
    const mobileRegex = /^[0-9]{10}$/;
    const today = new Date().toISOString().split("T")[0]; // Get today's date in YYYY-MM-DD format

    if (!nameRegex.test(formData.name)) {
      newErrors.name = "Name should contain only alphabets.";
    }

    if (!mobileRegex.test(formData.phone)) {
      newErrors.phone = "Mobile Number should be exactly 10 digits.";
    }

    if (!formData.appoinmentDate) {
      newErrors.appoinmentDate = "Please select an appointment date.";
    } else if (formData.appoinmentDate < today) {
      newErrors.appoinmentDate = "Appointment date cannot be in the past.";
    }

    if (!formData.hospital) {
      newErrors.hospital = "Please select a preferred hospital.";
    }
    if (!formData.doctor) {
      newErrors.doctor = "Please select a preferred doctor.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // True if no errors
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      console.log("Appointment Details Submitted:", formData);
      setFormData({
        name: "",
        phone: "",
        appoinmentDate: "",
        hospital: "",
        doctor: "",
      });
      setErrors({});
      setShowSuccessModal(true);
    }
  };

  return (
    <>
      <Header />
      <div className="search-bar">
        <h2 className="text-center fw-bold p-4">Search For Best Doctors</h2>
        <Container>
          <Row>
            <Col lg={6} sm={12} className="p-2">
              <FontAwesomeIcon icon={faSearch} className="search" />
              <input
                className="input-field p-2"
                type="text"
                placeholder="Search by : Doctors"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </Col>
            <Col lg={6} sm={12} className="p-2">
              <FontAwesomeIcon icon={faLocationDot} className="location" />
              <select
                name="hospital"
                className="select-field"
                value={selectedHospital}
                onChange={(e) => setSelectedHospital(e.target.value)}
              >
                <option value="">Select Hospital</option>
                <option value="Apollo">Apollo</option>
                <option value="Manipal Hospital">Manipal Hospital</option>
                <option value="Narayana Health">Narayana Health</option>
                <option value="Devadoss Hospital">Devadoss Hospital</option>
                <option value="Shalby Hospital">Shalby Hospital</option>
                <option value="SevenHills Hospital">SevenHills Hospital</option>
              </select>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="doctorcards p-5">
        <div className="abtheading text-center fw-bold">
          <h1 className="p-2" style={{ color: "#028885", fontSize: "50px" }}>
            Team of Experts
          </h1>
          <h4 className="p-2 " style={{ color: " #007c9d" }}>
            Meet the experts behind Google Health's healthcare technology
            advancements
          </h4>
        </div>
        <Container>
          <Row>
            {filteredDoctors.length > 0 ? (
              filteredDoctors.map((doctor, i) => (
                <DoctorCard dItems={doctor} key={i} />
              ))
            ) : (
              <h3 className="text-center p-4">No doctors found</h3>
            )}
          </Row>
        </Container>
      </div>
      <div className="bookapp">
        <Container className="d-flex justify-content-center">
          <Row>
            <Col
              lg={6}
              md={12}
              sm={12}
              className="d-flex justify-content-center"
            >
              <img
                src="images/appoint_bg_doc.png"
                alt="Medical Appoinment Image"
                className="mw-100"
                style={{ maxHeight: "min-content" }}
              />
            </Col>
            <Col lg={6} md={12} sm={12}>
              <div className="form">
                <h2 className="text-center p-4 fw-bold">Book an Appoinment</h2>
                <form className="p-3 rounded book-form" onSubmit={handleSubmit}>
                  <label className="form-label">Name:</label>
                  <input
                    type="text"
                    name="name"
                    className="form-control"
                    placeholder="Enter patient's name"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                  {errors.name && (
                    <p className="text-danger bg-warning p-1 rounded">
                      {errors.name}
                    </p>
                  )}
                  <label className="form-label">Phone Number:</label>
                  <input
                    type="tel"
                    name="phone"
                    className="form-control"
                    placeholder="Enter your phone number"
                    value={formData.phone}
                    onChange={handleInputChange}
                  />
                  {errors.phone && (
                    <p className="text-danger bg-warning p-1 rounded">
                      {errors.phone}
                    </p>
                  )}

                  <label className="form-label">Appoinment Date:</label>
                  <input
                    type="date"
                    name="appoinmentDate"
                    value={formData.appoinmentDate}
                    onChange={handleInputChange}
                  />
                  {errors.appoinmentDate && (
                    <p className="text-danger bg-warning p-1 rounded">
                      {errors.appoinmentDate}
                    </p>
                  )}
                  <label htmlFor="Hospitals">Choose prefered Hospitals:</label>
                  <select
                    name="hospital"
                    value={formData.hospital}
                    onChange={handleInputChange}
                  >
                    <option value="">Choose prefered Hospitals:</option>
                    <option value="Apollo">Apollo</option>
                    <option value="Manipal Hospital">Manipal Hospital</option>
                    <option value="Narayana Health">Narayana Health</option>
                    <option value="Devadoss Hospital">Devadoss Hospital</option>
                    <option value="Shalby Hospital">Shalby Hospital</option>
                    <option value="SevenHills Hospital">
                      SevenHills Hospital
                    </option>
                  </select>
                  {errors.hospital && (
                    <p className="text-danger bg-warning p-1 rounded">
                      {errors.hospital}
                    </p>
                  )}
                  <label htmlFor="Hospitals">
                    Choose preffered doctor if any:
                  </label>
                  <select
                    name="doctor"
                    value={formData.doctor}
                    onChange={handleInputChange}
                  >
                    <option value="">Choose prefered Doctor (if any):</option>
                    <option value="Dr. Emily Larson">Dr. Emily Larson</option>
                    <option value="Dr. Sarah Patel">Dr. Sarah Patel</option>
                    <option value="Dr. Christopher Davis">
                      Dr. Christopher Davis
                    </option>
                    <option value="Dr. Ava Mitchell">Dr. Ava Mitchell</option>
                    <option value="Dr. Zoe Kelly">Dr. Zoe Kelly</option>
                  </select>
                  {errors.doctor && (
                    <p className="text-danger bg-warning p-1 rounded">
                      {errors.doctor}
                    </p>
                  )}
                  <input type="submit" value="Book Appointment" />
                </form>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
      {/* Success Modal */}
      <Modal
        show={showSuccessModal}
        onHide={() => setShowSuccessModal(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title style={{ position: "relative" }}>Success</Modal.Title>
          <img
            src="\images\tick.png"
            alt=""
            style={{
              width: "90px",
              position: "absolute",
              justifySelf: "anchor-center",
              display: "flex",
              top: "-40px",
            }}
          />
        </Modal.Header>
        <Modal.Body>
          <p>Your appointment is successfully booked!</p>
          <br />
          <p>Thank You for book an appointment!</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={() => setShowSuccessModal(false)}>
            OK
          </Button>
        </Modal.Footer>
      </Modal>
      <section className="section-download">
        <Container>
          <Row>
            <Col lg={6} md={12} sm={12}>
              <div className="dbanner">
                <img src="images/downloadbanner.png" alt="app_mobile" />
              </div>
            </Col>
            <Col lg={6} md={12} sm={12}>
              <div className="app-center p-5 text-center">
                <h2 className="p-3">Download DocHub App</h2>
                <p>Book appointment & health checkups;</p>
                <p>Online lab test & consult doctor online</p>
                <p>Get the link to download the app</p>
                <div className="download-btn pt-5">
                  <a
                    href="https://play.google.com/store/games?hl=en"
                    target="blank"
                  >
                    <img src="images/play-store.png" alt="" className="p-2" />
                    Play Store
                  </a>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      <ScrollToTop smooth color="#028885" />
      <Footer />
    </>
  );
}
