const patientData = [
  {
    id: 1,
    image: "images/patients.svg",
    body: "50+ patients have used DocHub services",
  },
  {
    id: 2,
    image: "images/hospitals.svg",
    body: "50+ Hospitals across Gujarat",
  },
  {
    id: 3,
    image: "images/doctors.svg",
    body: "50+ Specialist doctors available",
  },
];

export default patientData;
