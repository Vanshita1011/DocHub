import React from "react";
import { useParams } from "react-router-dom";
import Header from "../../common/Header";
import { Card, Col, Container, Row } from "react-bootstrap";
import Footer from "../../common/footer";
import Slot from "./Slot";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleInfo } from "@fortawesome/free-solid-svg-icons/faCircleInfo";

const doctorsData = [
  {
    id: "1",
    img: "/images/docimg/1.png",
    name: "Dr. Jane Smith",
    title: "General physician",
    experience: "8 year",
    about:
      "Dr. Jane Smith has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "2",
    img: "/images/docimg/2.png",
    name: "Dr. Emily Larson",
    title: "Gynecologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "3",
    img: "/images/docimg/3.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "4",
    img: "/images/docimg/4.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "5",
    img: "/images/docimg/5.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "6",
    img: "/images/docimg/6.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "7",
    img: "/images/docimg/7.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "8",
    img: "/images/docimg/8.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "9",
    img: "/images/docimg/9.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "10",
    img: "/images/docimg/10.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "11",
    img: "/images/docimg/11.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "12",
    img: "/images/docimg/12.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "13",
    img: "/images/docimg/13.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "14",
    img: "/images/docimg/14.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "15",
    img: "/images/docimg/15.png",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
  {
    id: "16",
    img: "/images/docimg/16.jpeg",
    name: "Dr. Jane",
    title: "Dermatologist",
    experience: "8 years",
    about:
      "Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Davis has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies.",
    fee: " $50 ",
  },
];

export default function Bookdetails() {
  const { id } = useParams(); // Get doctor ID from URL
  const doctor = doctorsData.find((doc) => doc.id === id);

  if (!doctor) {
    return <h2>Doctor not found</h2>;
  }

  return (
    <>
      <Header />
      <Container>
        <Row className="p-5">
          <Col lg={6} md={12} sm={12}>
            <img
              src={doctor.img}
              alt=""
              className="mw-100"
              style={{ backgroundColor: "#6c63ff" }}
            />
          </Col>
          <Col
            style={{ border: " 1px solid rgb(160, 143, 143)" }}
            lg={6}
            md={12}
            sm={12}
            className="p-5 "
          >
            <h1
              className="p-1"
              style={{ color: "rgba(0, 124, 157, 0.9)", fontWeight: "bold" }}
            >
              {doctor.name}
            </h1>

            <p className="p-1">{doctor.title}</p>

            <p className="p-1">
              <strong>Experience:</strong> {doctor.experience}
            </p>
            <strong style={{ padding: "5px" }}>About</strong>
            <FontAwesomeIcon icon={faCircleInfo} />
            <p className="p-1">{doctor.about}</p>
            <p className="p-1">
              <strong>Appoinment fee:</strong> {doctor.fee}
            </p>
          </Col>
        </Row>
      </Container>
      <Slot />
      <Footer />
    </>
  );
}
